-- ============================================
-- Step 1: Create Database, Schema, Warehouse
-- ============================================
CREATE OR REPLACE DATABASE LEARN_SNOWFLAKE;
CREATE OR REPLACE SCHEMA LEARN_SNOWFLAKE.TRAINING;
USE SCHEMA LEARN_SNOWFLAKE.TRAINING;

CREATE OR REPLACE WAREHOUSE LEARN_WH 
  WITH WAREHOUSE_SIZE = 'XSMALL' 
  AUTO_SUSPEND = 60 
  AUTO_RESUME = TRUE 
  INITIALLY_SUSPENDED = TRUE;

-- ============================================
-- Step 2: Create Stage (for file loading)
-- ============================================
CREATE OR REPLACE STAGE MY_STAGE;

-- Upload files (sales.csv, customers.csv, products.csv, orders.json) 
-- into stage via Web UI or SnowSQL:
--    PUT file://path_to_file/sales.csv @MY_STAGE AUTO_COMPRESS=TRUE;

-- ============================================
-- Step 3: Create Tables
-- ============================================

-- Customers Table
CREATE OR REPLACE TABLE CUSTOMERS (
    CustomerID INT,
    Name STRING,
    City STRING
);

-- Products Table
CREATE OR REPLACE TABLE PRODUCTS (
    ProductID INT,
    ProductName STRING,
    Price NUMBER(10,2)
);

-- Sales Table
CREATE OR REPLACE TABLE SALES_RAW (
    OrderID INT,
    CustomerID INT,
    Date STRING,
    Amount STRING
);

-- Orders JSON Table
CREATE OR REPLACE TABLE ORDERS_JSON (
    OrderID INT,
    CustomerID INT,
    Products VARIANT
);

-- ============================================
-- Step 4: Load Data into Tables
-- ============================================

-- Load Customers
COPY INTO CUSTOMERS
FROM @MY_STAGE/customers.csv
FILE_FORMAT = (TYPE = CSV FIELD_OPTIONALLY_ENCLOSED_BY='"' SKIP_HEADER=1);

-- Load Products
COPY INTO PRODUCTS
FROM @MY_STAGE/products.csv
FILE_FORMAT = (TYPE = CSV FIELD_OPTIONALLY_ENCLOSED_BY='"' SKIP_HEADER=1);

-- Load Sales (raw as text first)
COPY INTO SALES_RAW
FROM @MY_STAGE/sales.csv
FILE_FORMAT = (TYPE = CSV FIELD_OPTIONALLY_ENCLOSED_BY='"' SKIP_HEADER=1);

-- Load Orders JSON
COPY INTO ORDERS_JSON (OrderID, CustomerID, Products)
FROM @MY_STAGE/orders.json
FILE_FORMAT = (TYPE = JSON);

-- ============================================
-- Step 5: Data Transformation Example
-- ============================================

-- Create a cleaned sales table with correct data types
CREATE OR REPLACE TABLE SALES_CLEANED AS
SELECT
    OrderID::INT AS OrderID,
    CustomerID::INT AS CustomerID,
    TO_DATE(Date, 'YYYY-MM-DD') AS OrderDate,
    Amount::NUMBER(10,2) AS Amount
FROM SALES_RAW;

-- Verify
SELECT * FROM CUSTOMERS;
SELECT * FROM PRODUCTS;
SELECT * FROM SALES_CLEANED;
SELECT * FROM ORDERS_JSON;


--======================================================================

With this script, learners can:

Create DB/Schema/Warehouse.

Upload datasets into stage (PUT command).

Run COPY INTO to load data.

Transform sales into a clean table.

Query JSON orders with : syntax.